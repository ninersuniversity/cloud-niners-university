<?php include('../config/auto_load.php'); ?>

<?php include('laporan_control.php'); ?>


<?php include('../template/header.php'); ?>

<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800">Laporan Pendaftaran</h1>
  
  <a href="<?= $base_url ?>/cetak/data_pendaftar.php" class="btn btn-warning btn-sm mb-3" target="_blank">Cetak Data Pendaftar PDF</a> 
  <a href="<?= $base_url ?>/cetak/data_excel.php" class="btn btn-success btn-sm mb-3" target="_blank">Cetak Data Pendaftar EXCEL</a> 

  <div class="row">
    <div class="col-md-12">
      <table class="table table-bordered table-hover">
      <tr>
            <td>No</td>
            <td>Nama Lengkap</td>
            <td>Tanggal Lahir</td>
            <td>Jenis Kelamin</td>
            <td>Fakultas / Jurusan</td>
            <td>Jenis Beasiswa</td>
            <td>Email</td>
            <td>No Telepon</td>
            <td>Status</td>
          </tr>

          <?php
          $no = 1;
          while($p = mysqli_fetch_array($all_pendaftar)) { ?>

          <tr>
            <td><?= $no++ ?></td>
            <td><?= $p['nama_lengkap'] ?></td>
            <td><?= $p['tgl_lahir'] ?></td>
            <td><?= $p['jenis_kelamin'] ?></td>
            <td><?= $p['fakultas_jurusan'] ?></td>
            <td><?= $p['jenis_beasiswa'] ?></td>
            <td><?= $p['email'] ?></td>
            <td><?= $p['telepon'] ?></td>
            <td><span class="badge badge-info">BARU</span></td>
          </tr>

        <?php }
        
        
        if(mysqli_num_rows($all_pendaftar) == 0) {
          echo "<tr><td colspan='8' align='center'><b>Belum Ada pendaftar baru</b></td></tr>";
        }

        ?>

      </table>
    </div>
  </div>
</div>
<!-- /.container-fluid -->

<?php include('../template/footer.php'); ?>