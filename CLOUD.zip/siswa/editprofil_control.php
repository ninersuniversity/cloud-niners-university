<?php

$id_user = $_SESSION['id_users'];
$sql_pendaftar = "SELECT * FROM pendaftar where users_id = '$id_user'";
$result_pendaftar = mysqli_query($koneksi, $sql_pendaftar);

if(mysqli_num_rows($result_pendaftar)){

    $data_pendaftar = mysqli_fetch_array($result_pendaftar);

    if(isset($_POST['btn_simpan']) && $_POST['btn_simpan'] == 'simpan_profil') {
        
        $id_pendaftar = $data_pendaftar['id'];
        $nama_lengkap = $_POST['nama_lengkap'];
        $tempat_lahir = $_POST['tempat_lahir'];
        $tgl_lahir = date("Y-m-d", strtotime($_POST['tgl_lahir']));
        $jenis_kelamin = $_POST['jenis_kelamin'];
        $agama = $_POST['agama'];
        $alamat = $_POST['alamat'];
        $email = $_POST['email'];
        $telepon = $_POST['telepon'];

        

        $sql_update_profil = "UPDATE pendaftar set nama='$nama_lengkap', tempat_lahir='$tempat_lahir', tgl_lahir='$tgl_lahir', jenis_kelamin='$jenis_kelamin', agama='$agama', alamat='$alamat', email='$email', telepon='$telepon' where id='$id_pendaftar'";

        $query_update_profil = mysqli_query($koneksi, $sql_update_profil);

        if($query_update_profil) {
            // berhasil
            $_SESSION['pesan_sukses'] = "Edit Profil Sukses!";
            
            header('location:dashboard.php');
        } else {
            echo "gagal update data profil"; die;
        }

    }

}

?>