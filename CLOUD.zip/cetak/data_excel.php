<?php

header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Data pendaftaran.xls");

include('../config/koneksi.php');

// tabel pendaftar
$all_pendaftar = mysqli_query($koneksi, "SELECT * FROM pendaftar");

$html = '
<table width="100%" border="1">
<tr>
    <th width="5%">No</th>
    <th width="13%">Nama</th>
    <th width="20%">TTL</th>
    <th width="5%">JK</th>
    <th>Alamat</th>
    <th width="7%">Telepon</th>
</tr>';

$no = 1;
while($p = mysqli_fetch_array($all_pendaftar)) { 
    

    $html .= '
    <tr>
        <td align="center">'. $no++ . '</td>
        <td>'. $p['nama_lengkap'] . '</td>
        <td>'. $p['tempat_lahir'] . ', '. $p['tgl_lahir'] . '</td>
        <td align="center">'. $p['jenis_kelamin'] . '</td>
        <td>'. $p['alamat'] . '</td>
        <td>'. $p['telepon'] . '</td>
    </tr>';

}

$html .= '
</table>';

echo $html;